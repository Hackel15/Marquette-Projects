Python 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 07:18:10) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
 RESTART: C:/Users/tyler.DESKTOP-7I7VF8T/Desktop/OneDrive/Marquette/Spring17/Computer/Week_4/Task_2.py 
>>> 
>>> guessing_game()
Enter guess: 50
TOO HIGH
Enter guess: 25
TOO HIGH
Enter guess: 12
TOO LOW
Enter guess: 16
TOO LOW
Enter guess: 20
TOO LOW
Enter guess: 22
CORRECT GUESS! YOU WIN!
Random #: 22 , Total guesses: 6
>>> guessing_game()
Enter guess: 50
TOO LOW
Enter guess: 25
TOO LOW
Enter guess: 75
TOO LOW
Enter guess: 88
TOO HIGH
Enter guess: 79
TOO LOW
Enter guess: 84
TOO LOW
Enter guess: 86
CORRECT GUESS! YOU WIN!
Random #: 86 , Total guesses: 7
>>> guessing_game()
Enter guess: 50
TOO LOW
Enter guess: 75
TOO LOW
Enter guess: 90
TOO HIGH
Enter guess: 85
CORRECT GUESS! YOU WIN!
Random #: 85 , Total guesses: 4
>>> 
