Python 3.6.0 (v3.6.0:41df79263a11, Dec 23 2016, 07:18:10) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
 RESTART: C:/Users/tyler.DESKTOP-7I7VF8T/Desktop/OneDrive/Marquette/Spring17/Computer/Week_3/Act_6.py 
Enter an integer 'n': 1
*****     
*****     
*****     
     *****
     *****
     *****
>>> 
