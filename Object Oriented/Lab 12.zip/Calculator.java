package swing;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
TYLER HACKEL
Calculator 
Lab
*/
public class Calculator extends JFrame 
                        implements ActionListener
{
    public static final int WIDTH = 400;
    public static final int HEIGHT = 400;
    public static final int NUMBER_OF_DIGITS = 30;

    private JLabel ioField;
    private JLabel operand;
    private double result = 0.0;
    private double input = 0.0;
    private boolean flag = false;

    public static void main(String[] args)
    {
        Calculator aCalculator = new Calculator( );
        aCalculator.setVisible(true);
    }

    public Calculator( )
    {
        setTitle("Simplified Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(WIDTH, HEIGHT);
        setLayout(new BorderLayout());

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new GridLayout(1, 4));
        
        JLabel resultLabel = new JLabel();
        resultLabel.setText("Result: ");
        textPanel.add(resultLabel);
        
        ioField = new JLabel();
        ioField.setText("0.0");
        textPanel.add(ioField);
        
        JLabel operandLabel = new JLabel();
        operandLabel.setText("Operand: ");
        textPanel.add(operandLabel);
        
        operand = new JLabel();
        operand.setText("0.0");
        textPanel.add(operand);
        
        add(textPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel( );
        buttonPanel.setBackground(Color.GRAY);
        buttonPanel.setLayout(new GridLayout(5, 4));

        JButton addButton = new JButton("+"); 
        addButton.addActionListener(this);
        buttonPanel.add(addButton); 
        
        JButton subtractButton = new JButton("-"); 
        subtractButton.addActionListener(this);
        buttonPanel.add(subtractButton);
        
        JButton multiplyButton = new JButton("x");
        multiplyButton.addActionListener(this);
        buttonPanel.add(multiplyButton);
        
        JButton divideButton = new JButton("/");
        divideButton.addActionListener(this);
        buttonPanel.add(divideButton);
        
        JButton zeroButton = new JButton("0");
        zeroButton.addActionListener(this);
        buttonPanel.add(zeroButton);
        
        JButton oneButton = new JButton("1");
        oneButton.addActionListener(this);
        buttonPanel.add(oneButton);
        
        JButton twoButton = new JButton("2");
        twoButton.addActionListener(this);
        buttonPanel.add(twoButton);
        
        JButton threeButton = new JButton("3");
        threeButton.addActionListener(this);
        buttonPanel.add(threeButton);
        
        JButton fourButton = new JButton("4");
        fourButton.addActionListener(this);
        buttonPanel.add(fourButton);
        
        JButton fiveButton = new JButton("5");
        fiveButton.addActionListener(this);
        buttonPanel.add(fiveButton);
        
        JButton sixButton = new JButton("6");
        sixButton.addActionListener(this);
        buttonPanel.add(sixButton);
        
        JButton sevenButton = new JButton("7");
        sevenButton.addActionListener(this);
        buttonPanel.add(sevenButton);
        
        JButton eightButton = new JButton("8");
        eightButton.addActionListener(this);
        buttonPanel.add(eightButton);
        
        JButton nineButton = new JButton("9");
        nineButton.addActionListener(this);
        buttonPanel.add(nineButton);
        
        JButton dot = new JButton(".");
        dot.addActionListener(this);
        buttonPanel.add(dot);
        
        JButton resetButton = new JButton("Reset"); 
        resetButton.addActionListener(this);
        buttonPanel.add(resetButton);
        
        JButton clearButton = new JButton("Clear"); 
        clearButton.addActionListener(this);
        buttonPanel.add(clearButton);   
        
        add(buttonPanel);
    }


    public void actionPerformed(ActionEvent e)
    {
    	assumingCorrectNumberFormats(e);
    }


    //Throws NumberFormatException.
    public void assumingCorrectNumberFormats(ActionEvent e)
    {
        String actionCommand = e.getActionCommand( );
        
        if (operand.getText().equals("0.0") || flag)
        {
        	operand.setText("");
        	input = 0.0;
        	flag = false;
        }
        
        if (actionCommand.equals("0"))
        {
        	operand.setText(operand.getText().concat("0"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("1"))
        {
        	operand.setText(operand.getText().concat("1"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("2"))
        {
        	operand.setText(operand.getText().concat("2"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("3"))
        {
        	operand.setText(operand.getText().concat("3"));  
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("4"))
        {
        	operand.setText(operand.getText().concat("4"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("5"))
        {
        	operand.setText(operand.getText().concat("5"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("6"))
        {
        	operand.setText(operand.getText().concat("6"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("7"))
        {
        	operand.setText(operand.getText().concat("7"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("8"))
        {
        	operand.setText(operand.getText().concat("8"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("9"))
        {
        	operand.setText(operand.getText().concat("9"));
        	input = stringToDouble(operand.getText());
        }
        else if (actionCommand.equals("."))
        {
        	if (operand.getText().indexOf(".") == -1)
        	{
        		operand.setText(operand.getText().concat("."));
        		input = 0.0 + input;
        	}
        	else
        	{
        		
        	}
        }
        else if (actionCommand.equals("+"))
        {
        		result = result + input;
        		ioField.setText(Double.toString(result));
        		operand.setText("0.0");
        		input = 0.0;
        }
        else if (actionCommand.equals("-"))
        {
        		result = result - input;
        		ioField.setText(Double.toString(result));
        		operand.setText("0.0");
        		input = 0.0;
        }
        else if (actionCommand.equals("/")) 
        {
        	if(input != 0)
        	{
        		result = result / input;
            	ioField.setText(Double.toString(result));
            	operand.setText("0.0");
            	input = 0.0;
        	}
        	else
        	{
        		input = 0.0;
        		operand.setText("Divivion by zero!");
        		flag = true;
        	}
        }
        else if (actionCommand.equals("x"))
        {
        	result = result * input;
        	ioField.setText(Double.toString(result));
        	operand.setText("0.0");
        	input = 0.0;
        }
        else if (actionCommand.equals("Reset"))
        {
            operand.setText("0.0");
            ioField.setText("0.0");
            result = 0.0;
            input = 0.0;
        }
        else if (actionCommand.equals("Clear"))
        {
        	operand.setText("0.0");
        	input = 0.0;
        }
        else
            ioField.setText("Error 2");
     }


    //Throws NumberFormatException.
    private static double stringToDouble(String stringObject)
    {
        return Double.parseDouble(stringObject.trim( ));
    }

}
