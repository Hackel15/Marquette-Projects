/**
 * Data Structure of this program.
 * This orders the data in a doubly linked list
 * @author tyler
 * @param <T>
 */


public class DLinkedList<T extends Comparable<T>> {
        
        /**
         * Instance variables for class
         */
	private Link<T> firstLink;//holds value of first link
	private final Link<T> lastLink;//holds value of null
        private int size; 
	
        /**
        * Constructor.
        * Initialize firstLinnk to null
        * Initialize lastLink to a new link with null data
        * Initialize size to zero
        */
	DLinkedList(){
            super();
            firstLink = new Link(null);
            lastLink = new Link(null);
            size = 0;
	}
        
        public Link<T> getHead(){
            return this.firstLink.getPrev();
        }
        
        public Link<T> getTail(){
            return this.lastLink.getNext();
        }
        
        /**
         * This method increments the number of linked lists by one
         * This does not include the lastLink
         */
        private void incrementSize(){
            size++;
        }
        
        /**
         * This method decrements the number of linked lists by one
         */
        private void decrementSize(){
            size--;
        }
        
        /**
         * isEmpty method is used to determine an empty linked list
         * @return boolean type
         */
        public boolean isEmpty(){
            boolean set = false;
            if(size == 0)
                set = true;
            return set;
        }
        
        /**
         * addLink method creates a new link of data
         * @param data is stored in a new link
         */
        public void addLink(T data){
            if(isEmpty()){
                Link<T> temp = new Link<>(data);
		temp.setPrev(lastLink);
                temp.setNext(firstLink);
                firstLink.setPrev(temp);
                lastLink.setNext(temp);
                incrementSize();
            }else{
                Link<T> temp = new Link<>(data);
                temp.setPrev(lastLink);
                lastLink.getNext().setPrev(temp);
                temp.setNext(lastLink.getNext());
                lastLink.setNext(temp);
            
                incrementSize();
                //insertSort();
            }
        }
        
        /**
         * printLinks returns a string of the records
         * @return s
         */
        public String printLinks(){
            String s = "";
            Link<T> temp = firstLink.getPrev();
            while(temp != lastLink){
                s += temp.returnData().toString();
                temp = temp.getPrev();
            }
            return s;
        }
        
        public void removeAtHead(){
            Link<T> temp = this.getHead();
            temp.getPrev().setNext(firstLink);
            firstLink.setPrev(temp.getPrev());
            //firstLink.setPrev(null);
            decrementSize();
        }
        
        /**
         * removeLink method removes a specified link, if found.
         * @param delete is a string name, found in a Record
         * @return is 
         * false is returned if link is not found
         * true is returned if link is found and removed
         */
        public boolean removeLink(T delete){
            Link<T> temp = firstLink;
            
            boolean is = false;
            while(temp.getNext() != null){
		if(temp.returnData().compareTo(delete) == 0){
                    //delete here (swaping nodes)
                    is = true;
                    decrementSize();
                    if(temp.getPrev() == null){
                        firstLink = temp.getNext();
                        //firstLink.setPrev(null);
                        break;
                    }else if(temp.getNext() == null){
                        temp.getPrev().setNext(temp.getNext());
                        break;
                    }else{
                        temp.getPrev().setNext(temp.getNext());
                        temp.getNext().setPrev(temp.getPrev());
                        break;
                    }
                }
                temp = temp.getNext();
            }
            return is;
        }
        
        /**
         * insortSort method sorts the newly inserted link
         */
        private void insertSort(){
            Link<T> last = lastLink.getNext();
            Link<T> next = last.getNext();
            
            while(next != firstLink){
                if(last.returnData().compareTo(next.returnData())<= 0){
                    T temp;
                    temp = last.returnData();
                    last.setData(next.returnData());
                    next.setData(temp);
                    
                    last = next;
                    next = last.getNext();
                }else{
                    //System.out.println("break");
                    break;
                }
            }
        }   
    }