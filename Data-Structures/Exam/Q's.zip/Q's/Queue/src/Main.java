import java.util.Scanner;

/**
 * Computer Science II
 * @author Tyler Hackel
 * Doubly Linked List
 */
public class Main {
    public static void main(String [] args){
        String inFileName = null;//file name
        Queue pancakes = new Queue();
        
        Scanner inFile = null;//inFile for input data
        Scanner input = new Scanner(System.in);//user input
      
        //Input desired input file
        //System.out.print("Enter desired input file: ");
        inFileName = "mydata.dat";
        inFile = FileUtils.ScannerOpen(inFileName);
        Record sap = new Record();
        
        System.out.println("Reading data in from: " + inFileName);
        while(inFile.hasNext()){
            Record syrup = new Record();
            syrup.readRecord(inFile);
            pancakes.enqueue(syrup);
        }
        System.out.println("Closing file: " + inFileName + "\n");
        inFile.close();
        
        System.out.println("QUEUE EXAMPLE");
  
        System.out.println("Peek at top pancake: "+ pancakes.peek().toString());
        System.out.println("Printing out DLL from top to bottom: \n"
                + pancakes.dll.printLinks());
        
        System.out.println("Removing top pancake: " + pancakes.dequeue().toString());
        System.out.println("Peek at top pancake: " + pancakes.peek().toString());
        
        System.out.println("Removing top pancake: " + pancakes.dequeue().toString());
        System.out.println("Peek at top pancake: " + pancakes.peek().toString());
        
        System.out.println("Removing top pancake: " + pancakes.dequeue().toString());
        System.out.println("Peek at top pancake: " + pancakes.peek().toString());
        
        System.out.println("Removing top pancake: " + pancakes.dequeue().toString());
        System.out.println("Peek at top pancake: " + pancakes.peek().toString());
        
        System.out.println("Removing top pancake: " + pancakes.dequeue().toString());
        System.out.println("Peek at top pancake: " + pancakes.peek().toString());        
        
        System.out.println("Adding dummy pancake to stack!");
        pancakes.enqueue(sap);
        
        System.out.println("Peek at top pancake: "+ pancakes.peek().toString());
        
        System.out.println("Printing out DLL from top to bottom: \n"
                + pancakes.dll.printLinks());
                
        
    }
     
}

