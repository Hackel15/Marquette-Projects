import java.util.Random;

public class Link<T>{
	
        /**
         * Instance variables
         */
	private T data;//data stored
	private Link<T> next;//next link stored
	private Link<T> prev;//previous link stored
	private int priority;
        /**
         * Constructor
         * @param that initializes data
         */
	Link(T that){
            super();
            this.data = that;
            Random rand = new Random();
            this.priority = rand.nextInt(5)+1;
	}
	
        public void setPriority(int p){
            this.priority = p;
        }
        
        /**
         * Mutator method that sets next link 
         * @param that 
         */
	public void setNext(Link<T> that){
		this.next = that;
	}
	
        /**
         * Mutator method that sets previous link
         * @param that 
         */
	public void setPrev(Link<T> that){
		this.prev = that;
	}
        
        /**
         * Mutator method that sets data
         * @param that 
         */
        public void setData(T that){
            this.data = that;
        }
	
        public int getPriority(){
            return this.priority;
        }
        
        /**
         * Accessor method that gets next link
         * @return this.next
         */
	public Link<T> getNext(){
		return this.next;
	}
	
        /**
         * Accessor method that gets next link
         * @return this.prev
         */
	public Link<T> getPrev(){
		return this.prev;
	}
	
        /**
         * Accessor method that gets next link
         * @return data
         */
	public T returnData(){
		return data;
	}

}