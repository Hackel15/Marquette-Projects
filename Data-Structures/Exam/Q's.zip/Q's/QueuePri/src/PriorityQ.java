/**
 *  Computer Science II
 * @author Tyler Hackel
 */


public class PriorityQ {
    
    /**
     * Instance Variables for Priority Queue
     */
    public DLinkedList dll;
    
    /**
     * Constructor
     * Instantiates a new Doubly Linked List
     */
    PriorityQ(){
        dll = new DLinkedList();
    }
    
    /**
     * isEmpty method that tests if the underlying doubly linked list is empty
     * @return true if doubly linked list is empty
     */
    public boolean isEmpty(){
        return dll.isEmpty();
    }
    
    /**
     * peek method returns the head of the linked list (LIFO)
     * @return Record value of the doubly linked list
     */
    public Record peek(){
        if(this.isEmpty()){
            System.out.println("There are no pancakes to peek at!");
            System.exit(1);
            return null;
        }else{
            Link<Record> link = dll.getHead();
            return link.returnData();
        }
    }
    
    /**
     * dequeue method uses the "head" value of the doubly linked list and 
     * assigns a new "head" value to the link next in line.
     * @return Record 
     */
    public Record dequeue(){
        Link<Record> link;
        if(this.isEmpty()){
            System.out.println("Stack is empty!");
            System.exit(1);
            return null;
        }else{
            link = dll.getHead();
            dll.removeAtHead();
            return link.returnData();
        }
        
    }
    
    /**
     * enqueue method adds uses the underlying doubly linked list to add a new
     * link to the top of the stack
     * @param data
     */
    public void enqueue(Record data){
        dll.addLink(data);
    }
}
