/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Computer Science II
 * @author Tyler Hackel
 * Professor Turnage 
 */

public class BST<T extends Comparable<T>> {
    
    //instance variable
    public static BSTNode root;
    
        //constructor
	public BST(){
		this.root = null;
	}
	
        //method to search binary tree using data input
	public boolean find(T id){
		BSTNode<T> current = root;
		while(current!=null){
			if(current.data==id){
				return true;
			}else if(current.data.compareTo(id) > 0){
				current = current.left;
			}else{
				current = current.right;
			}
		}
		return false;
	}
        
        //method to delete a child (left or right), parent, or root.  
        //returns true if deletion occurs
        //returns false if data is not found
	public boolean delete(T id){
		BSTNode<T> parent = root;
		BSTNode<T> current = root;
		boolean isLeftChild = false;
		//Case 1: The node isn't in the tree.
                while(current.data!=id){
			parent = current;
			if(current.data.compareTo(id) > 0){
				isLeftChild = true;
				current = current.left;
			}else{
				isLeftChild = false;
				current = current.right;
                        }
			if(current ==null){
				return false;
			}
		}
		//if i am here that means we have found the node
		//Case 2: if node to be deleted has no children
		if(current.left==null && current.right==null){
			if(current==root){
				root = null;
			}
			if(isLeftChild ==true){
				parent.left = null;
			}else{
				parent.right = null;
			}
		}
		//Case 3: if node to be deleted has only one child
		else if(current.right==null){
			if(current==root){
				root = current.left;
			}else if(isLeftChild){
				parent.left = current.left;
			}else{
				parent.right = current.left;
			}
		}
		else if(current.left==null){
			if(current==root){
				root = current.right;
			}else if(isLeftChild){
				parent.left = current.right;
			}else{
				parent.right = current.right;
			}
		}
                //Case 4: The node has 2 children
                else if(current.left!=null && current.right!=null){
                 
			//now we have found the minimum element in the right sub tree
			BSTNode successor = getSuccessor(current);
			if(current==root){
				root = successor;
			}else if(isLeftChild){
				parent.left = successor;
			}else{
				parent.right = successor;
			}			
			successor.left = current.left;
		}		
		return true;		
	}
	
        //method to get successor value
        //used when deleting a parent 
	public BSTNode<T> getSuccessor(BSTNode<T> deleteNode){
		BSTNode<T> successsor =null;
		BSTNode<T> successsorParent =null;
		BSTNode<T> current = deleteNode.right;
		while(current != null){
			successsorParent = successsor;
			successsor = current;
			current = current.left;
		}
		//check if successor has the right child, it cannot have left child for sure
		// if it does have the right child, add it to the left of successorParent.
                //successsorParent
		if(successsor != deleteNode.right){
			successsorParent.left = successsor.right;
			successsor.right = deleteNode.right;
		}
		return successsor;
	}   
        
        //method to insert a new value into binary tree
         public void insert(T id){
		BSTNode<T> newBSTNode = new BSTNode(id);
		if(root==null){
			root = newBSTNode;
			return;
		}
		BSTNode<T> current = root;
		BSTNode<T> parent = null;
		while(true){
			parent = current;
			if(id.compareTo(current.data) < 0){				
				current = current.left;
				if(current==null){
					parent.left = newBSTNode;
					return;
				}
			}else{
				current = current.right;
				if(current==null){
					parent.right = newBSTNode;
					return;
				}
			}
		}
	}
         
        //displays binary tree In-Order
	public void inOrderdisplay(BSTNode<T> root){
		if(root!=null){
			inOrderdisplay(root.left);
			System.out.print(" " + root.data);
			inOrderdisplay(root.right);
		}
	}
        
        //displays binary tree Pre-Order
        public void preOrderdisplay(BSTNode<T> root)
        {
            if(root != null){
                System.out.print(" " + root.data);
                preOrderdisplay(root.left);
                preOrderdisplay(root.right);
            }
        }
        
        //displays binary tree Post-Order
        public void postOrderdisplay(BSTNode<T> root)
        {
            if(root != null)
            {
                postOrderdisplay(root.left);
                postOrderdisplay(root.right);
                System.out.print(" " + root.data);
            }
        }
        
        //main method
        public static void main(String arg[]){
		BST<Integer> b = new BST<>();
		b.insert(3);b.insert(8);
		b.insert(1);b.insert(4);b.insert(6);b.insert(2);
                b.insert(10);b.insert(9);
		b.insert(20);b.insert(25);b.insert(15);b.insert(16);
		System.out.println("Display In-Order Integer Tree: ");
		b.inOrderdisplay(b.root);		
		System.out.println("\n");
                
                BST<String> a = new BST<>();
		a.insert("Vanilla");a.insert("Rocky-Road");
		a.insert("Chocolate");a.insert("Blueberry");a.insert("Mint");a.insert("Cookies-N'-Cream");
                a.insert("Coffee");a.insert("Milk-Dud");
		a.insert("Butter-Pecan");a.insert("Chunky-Road");a.insert("Peanut-Butter");a.insert("Strawberry");
		System.out.println("Display In-Order String Tree: ");
		a.inOrderdisplay(a.root);		
		System.out.println("\n");
                
                BST<Character> c = new BST<>();
		c.insert('A');c.insert('C');c.insert('Z');c.insert('V');
                c.insert('H');c.insert('Q');c.insert('B');c.insert('D');
                c.insert('M');c.insert('W');c.insert('R');c.insert('J');
                c.insert('O');c.insert('U');c.insert('T');c.insert('Y');
		System.out.println("Display In-Order Character Tree: ");
		c.inOrderdisplay(c.root);
                System.out.println("\n");
	}
}

