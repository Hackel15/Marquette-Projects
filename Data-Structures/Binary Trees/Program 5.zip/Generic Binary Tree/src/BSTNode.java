/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Computer Science II
 * @author Tyler Hackel
 * Professor Turnage 
 */

public class BSTNode<T> {
    
    //instance variables
    T data;
    BSTNode<T> left;
    BSTNode<T> right;
    
    //constructor
    public BSTNode(T d)
    {
        this.data = d;
        left = null;
        right = null;
    }
    
    //mutator method 
    public void setData(T d)
    {
        this.data = d;
    }
    
    //accessor method 
    public T getData()
    {
        return data;
    }
    
}
