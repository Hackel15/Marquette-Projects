/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Computer Science II
 * @author Tyler Hackel
 * Professor Turnage 
 */

public class BSTNode {
    
    //instance variables
    int data;
    BSTNode left;
    BSTNode right;
    
    //constructor
    public BSTNode(int d)
    {
        this.data = d;
        left = null;
        right = null;
    }
    
    //mutator method 
    public void setData(int d)
    {
        this.data = d;
    }
    
    //accessor method 
    public int getData()
    {
        return data;
    }
    
}
